package org.telstra.Tests;



import static org.testng.Assert.assertEquals;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;



import io.appium.java_client.android.AndroidDriver;


public class Ebay{
	
	 AndroidDriver driver;		

	@BeforeTest
	 public void getCapabilities() throws MalformedURLException
		{
		//Mandate capabilities to launch the device
         DesiredCapabilities capabilities = new DesiredCapabilities();
         capabilities.setCapability("deviceName","ce091609d9348f3101");	        
         capabilities.setCapability(CapabilityType.VERSION, "8.0");
         capabilities.setCapability("platformName", "Android");
         capabilities.setCapability("appPackage","com.ebay.mobile");
         capabilities.setCapability("appActivity","com.ebay.mobile.activities.MainActivity");  
         capabilities.setCapability("--session-override",true);
         driver = new AndroidDriver(new URL("http://0.0.0.0:4723/wd/hub"),capabilities);
 		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
		
		}
	@Test(priority=1)
	public void login() throws InterruptedException {
		driver.findElement(By.id("com.ebay.mobile:id/button_sign_in")).click();
		driver.findElement(By.id("com.ebay.mobile:id/button_classic")).click();
		driver.findElement(By.xpath("//hierarchy/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[2]/android.view.ViewGroup[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.ScrollView[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.EditText[1]")).sendKeys("saketh19@gmail.com");
		driver.findElement(By.id("com.ebay.mobile:id/et_temp")).sendKeys("saaki_143");
		driver.findElement(By.xpath("//hierarchy/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[2]/android.view.ViewGroup[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.ScrollView[1]/android.widget.LinearLayout[1]/android.widget.Button[1]")).click();
	    Reporter.log("user is able to successfuly login to the Ebay Mobile app");
	}
	 /* Swipe ScrollView from top to bottom */
	    public  void swipeScrollViewFromTopToBottom()
	    {
	        try
	        {
	        	Dimension size = driver.manage().window().getSize();
	        	int widthAnchor = (int) (size.width * 0.5);
			    int startheight = (int) (size.height * 0.8);
			    int endHeight = (int) (size.height * 0.3);

	            driver.swipe(widthAnchor, startheight, widthAnchor, endHeight, 1000);
	        }
	        catch (Exception ex)
	        {
	            ex.printStackTrace();
	        }
	    }

	@Test(priority=2)
	public void addtocart() throws InterruptedException {
		
		driver.findElement(By.id("com.ebay.mobile:id/search_box")).click();
		driver.findElement(By.id("com.ebay.mobile:id/search_src_text")).sendKeys("65-inch tv");
        driver.findElement(By.id("com.ebay.mobile:id/text")).click();
		Reporter.log("user is able to search for the 65-inch LED tv");
		Thread.sleep(3000);
	
		swipeScrollViewFromTopToBottom();
		String cart = driver.findElement(By.xpath("//androidx.recyclerview.widget.RecyclerView[@resource-id='com.ebay.mobile:id/recycler']/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/android.widget.TextView")).getText();
		driver.findElement(By.xpath("//androidx.recyclerview.widget.RecyclerView[@resource-id='com.ebay.mobile:id/recycler']/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/android.widget.TextView")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("com.ebay.mobile:id/button_add_to_cart")).click();
		driver.findElement(By.id("com.ebay.mobile:id/spinner_selection_option")).click();
		driver.findElement(By.xpath("//android.widget.ListView/android.widget.FrameLayout[3]/android.widget.LinearLayout/android.widget.TextView")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("com.ebay.mobile:id/button_add_to_cart_buybar")).click();
		Reporter.log("user is able to select the item and can be able to add it to the cart ");

		driver.findElement(By.id("com.ebay.mobile:id/action_view_icon")).click();
		Thread.sleep(2000);
		String checkout = driver.findElement(By.xpath("//androidx.recyclerview.widget.RecyclerView[@resource-id='com.ebay.mobile:id/shopping_cart_contents']/android.widget.LinearLayout[1]/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.widget.TextView")).getText();
		assertEquals(cart, checkout);
		Reporter.log("Product description in the product search page and check out page has been verified");
		}

}
